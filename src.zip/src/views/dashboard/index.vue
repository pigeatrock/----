<template>
  <div class="dashboard-container">
    <div class="dashboard-top"><h2>欢迎来到美图管理后台</h2></div>
    <div class="dashboard-name">网点名称：{{website_name}}</div>
    <div class="dashboard-name">网点地址：{{address}}</div>
    <div class="dashboard-name">网点电话：{{website_phone}}</div>
    <div class="dashboard-name">操作员：{{name}}</div>
    <el-row>
      <el-card>
        <div id="myChart" ref="myChart" :style="{width: '90%', height: '300px'}"></div>
      </el-card>
    </el-row>
    <el-row style="width:100%;margin:40px 0" type="flex" justify="space-between">
      <el-col :span="10">
        <el-card>
          <div id="myhistogram" ref="myhistogram" :style="{ height: '300px'}"></div>
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card>
          <div id="myRadar" ref="myRadar" :style="{ height: '300px'}"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
    
</template>

<script>
import { mapGetters } from 'vuex'
var colors = ['#36a3f7', '#d14a61'];
//引入基本模板
let echarts = require('echarts/lib/echarts')
 
// 引入折线图等组件
require('echarts/lib/chart/line')
require('echarts/lib/chart/bar')
// require('echarts/lib/chart/radar')
require('echarts/lib/chart/pie')

// 引入提示框和title组件，图例
require('echarts/lib/component/tooltip')
require('echarts/lib/component/title')
require('echarts/lib/component/legend')
require('echarts/lib/component/legendScroll')//图例翻译滚动


export default {
  data(){
    return{

    }
  },
   computed: {
    ...mapGetters([
      'website_name',
      'address',
      'website_phone',
      'name'
    ]),
  },

  methods:{
    //饼状图
    bingzhuang(){
      this.chart = echarts.init(this.$refs.myRadar);
      this.setBingzhuang();
    },
    setBingzhuang(){
      this.chart.setOption({
            // backgroundColor: '#fff',

        title: {
            text: '暂存提交比',
            left: 'center',
            top: 20,
            textStyle: {
                color: '#ccc'
            }
        },

        tooltip : {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },

        visualMap: {
            show: false,
            min: 80,
            max: 600,
            inRange: {
                colorLightness: [0, 1]
            }
        },
          series : [
          {
              name:'美图手机',
              type:'pie',
              radius : '55%',
              center: ['50%', '50%'],
              data:[
                  {value:30, name:'暂存'},
                  {value:100, name:'提交'},
              ].sort(function (a, b) { return a.value - b.value; }),
              roseType: 'radius',
              label: {
                  normal: {
                      textStyle: {
                          color: 'rgba(255, 255, 255, 0.3)'
                      }
                  }
              },
              labelLine: {
                  normal: {
                      lineStyle: {
                          color: 'rgba(255, 255, 255, 0.3)'
                      },
                      smooth: 0.2,
                      length: 10,
                      length2: 20
                  }
              },
              itemStyle: {
                  normal: {
                      color: '#c23531',
                      // shadowBlur: 200,
                      // shadowColor: 'rgba(0, 0, 0, 0.5)'
                  }
              },

              animationType: 'scale',
              animationEasing: 'elasticOut',
              animationDelay: function (idx) {
                  return Math.random() * 200;
              }
          }
        ]
      })
    },
    
    //柱状图
     zhuzhuang() {
      this.chart = echarts.init(this.$refs.myhistogram);
      this.setZhuzhuang();
    },
    setZhuzhuang(){
      color: colors,
      this.chart.setOption({
        title: {
          text: '维修单数'
        },
        tooltip: {
          trigger: 'none',
          axisPointer: {
            type: 'cross'
          }
        },
        legend: {
          data:['暂存单数', '提交单数']
        },
        grid: {
          top: 70,
          bottom: 50
        },
        xAxis: [
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true
            },
            axisLine: {
              onZero: false,
              lineStyle: {
                  color: colors[1]
              }
            },
           
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat","Sun"]
          },
          {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            axisLine: {
                onZero: false,
                lineStyle: {
                    color: colors[0]
                }
            },
           
            data:["Mon", "Tue", "Wed", "Thu", "Fri", "Sat","Sun"]
          }
        ],
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '暂存单数',
            type: 'bar',
            data: [5, 20, 36, 10, 10, 20,100],
             itemStyle:{
              color:colors[1]
            }
          },
          {
            name: '提交单数',
            type: 'bar',
            data: [79, 50, 30, 10, 60, 70,30],
             itemStyle:{
              color:colors[0]
            }
          }
        ]
      })
    },
    //折线图
    initCharts() {
      this.chart = echarts.init(this.$refs.myChart);
      this.setOptions();
    },
    setOptions() {
      color: colors,
      this.chart.setOption({
        title: {
          text: '美图手机维修单数'
        },
        tooltip: {
          trigger: 'none',
          axisPointer: {
            type: 'cross'
          }
        },
        legend: {
          data:['暂存单数', '提交单数']
        },
        grid: {
          top: 70,
          bottom: 50
        },
        xAxis: [
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true
            },
            axisLine: {
              onZero: false,
              lineStyle: {
                  color: colors[1]
              }
            },
            axisPointer: {
              label: {
                  formatter: function (params) {
                    
                      return '单数  ' + params.value
                          + (params.seriesData.length ? '：' + params.seriesData[0].data : '');
                  }
              }
            },
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat","Sun"]
          },
          {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            axisLine: {
                onZero: false,
                lineStyle: {
                    color: colors[0]
                }
            },
            axisPointer: {
                label: {
                    formatter: function (params) {
                     console.log(params)
                        return '单数  ' + params.value
                            + (params.seriesData.length ? '：' + params.seriesData[0].data : '');
                    }
                }
            },
            data:["Mon", "Tue", "Wed", "Thu", "Fri", "Sat","Sun"]
          }
        ],
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '暂存单数',
            type: 'line',
            data: [5, 20, 36, 10, 10, 20,100],
            itemStyle:{
              color:colors[1]
            }
          },
          {
            name: '提交单数',
            type: 'line',
            data: [79, 50, 30, 10, 60, 70,30],
            itemStyle:{
              color:colors[0]
            }
          }
        ]
      })
    }
  },
  mounted() {
    this.initCharts()
    this.zhuzhuang()
    this.bingzhuang()
  },
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.dashboard {
  // &-top{
  //   font-size: 20px;
  //   text-align: center;
  // }
  // &-name {
  //   padding-left:30px;
  //   cursor: pointer;
  //   font-size: 25px;
  //   line-height: 50px;
  // }
  // &-name:hover{
  //   background-color:#F8F8F8;
  // }
}
</style>